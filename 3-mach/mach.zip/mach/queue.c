#include "queue.h"

// TODO: includes, structs, variables

int queue_init(void) {
    // TODO: implement me
    return -1;
}

void queue_deinit(void) {
    // TODO: implement me
}

int queue_put(char *cmd, char *out, int flags) {
    // TODO: implement me
    return -1;
}

int queue_get(char **cmd, char **out, int *flags) {
    // TODO: implement me
    return -1;
}
